frappe.ui.form.on('Test Run', {

    onload: function (frm) {
        if (frm.is_new()) {
            frm.set_value('test_executed_by', frappe.session.user);
            frm.set_value('test_date', frappe.datetime.now_datetime());
        }

        frm.set_query('build_number', () => {
            return { filters: { is_active: 1 } };
        });
    },

    script_reference: async function (frm) {
        if (!frm.doc.script_reference) {
            clear_all_outcome_tables(frm);
            toggle_outcome_tables(frm, null);
            return;
        }

        try {
            const test_script_doc = await frappe.db.get_doc('Test Script Document', frm.doc.script_reference);
            const template_doc = await frappe.db.get_doc('Test Script Template', test_script_doc.template_name);
            const template_type = template_doc.template_type || '';

            clear_all_outcome_tables(frm);

            let source_table = [];
            let target_table = '';
            frm.doc.template_type = template_type;

            if (template_type === 'Test Script') {
                source_table = test_script_doc.test_details || [];
                target_table = 'test_outcomes';
            } else if (template_type === 'Marketing') {
                source_table = test_script_doc.marketing_test_details || [];
                target_table = 'marketing_test_outcomes';
            } else if (template_type === 'Production') {
                source_table = test_script_doc.production_test_details || [];
                target_table = 'production_test_outcomes';
            }

            source_table.forEach(detail => {
                const row = frm.add_child(target_table);
                row.test_case_id = detail.test_case_id || '';
                row.test_title = detail.test_title || '';
                row.step_description = detail.step_description || '';
                row.expected_result = detail.expected_result || '';
                row.actual_result = detail.actual_result || '';
                row.outcome = detail.outcome || '';
                row.notes = detail.notes || '';
                row.comments = detail.comments || '';
                row.result = detail.result || '';
            });

            frm.refresh_field('test_outcomes');
            frm.refresh_field('marketing_test_outcomes');
            frm.refresh_field('production_test_outcomes');

            toggle_outcome_tables(frm, template_type);

        } catch (error) {
            frappe.msgprint("Failed to load Test Script Document or Template.");
            console.error(error);
        }
    },

    refresh: function (frm) {
        add_raise_defect_button(frm);
    },

    after_save: function (frm) {
        frappe.set_route('List', frm.doctype);
    }

});

function clear_all_outcome_tables(frm) {
    frm.clear_table('test_outcomes');
    frm.clear_table('marketing_test_outcomes');
    frm.clear_table('production_test_outcomes');

    frm.refresh_field('test_outcomes');
    frm.refresh_field('marketing_test_outcomes');
    frm.refresh_field('production_test_outcomes');
}

function toggle_outcome_tables(frm, template_type) {
    frm.toggle_display('test_outcomes', template_type === 'Test Script');
    frm.toggle_display('marketing_test_outcomes', template_type === 'Marketing');
    frm.toggle_display('production_test_outcomes', template_type === 'Production');
}

function add_raise_defect_button(frm) {
    frm.remove_custom_button('Raise Defect for Selected Step');

    frm.add_custom_button('Raise Defect for Selected Step', () => {

        let grid = null;
        if (frm.fields_dict.test_outcomes.grid.wrapper.is(':visible')) {
            grid = frm.fields_dict.test_outcomes.grid;
        } else if (frm.fields_dict.marketing_test_outcomes.grid.wrapper.is(':visible')) {
            grid = frm.fields_dict.marketing_test_outcomes.grid;
        } else if (frm.fields_dict.production_test_outcomes.grid.wrapper.is(':visible')) {
            grid = frm.fields_dict.production_test_outcomes.grid;
        }

        if (!grid) {
            frappe.msgprint("Please load a script first.");
            return;
        }

        const selected_rows = grid.get_selected_children();

        if (selected_rows.length === 0) {
            frappe.msgprint("Please select one test step row first.");
            return;
        }
        if (selected_rows.length > 1) {
            frappe.msgprint("Please select only one test step row.");
            return;
        }

        const row = selected_rows[0];

        if (row.outcome !== 'Fail') {
            frappe.msgprint("Defect can only be raised if Outcome is marked as 'Fail'.");
            return;
        }

        frappe.model.with_doctype('Defect', () => {
            const defect = frappe.model.get_new_doc('Defect');
            defect.status = "New";
            defect.priority = "Medium";
            defect.severity = "Moderate";
            defect.build_number = frm.doc.build_number || '';
            defect.assigned_to = ''; 
            defect.assigned_by = frappe.session.user;

            defect.test_case_id = row.test_case_id || '';
            defect.test_title = row.test_title || '';
            defect.test_description = row.step_description || '';
            defect.expected_result = row.expected_result || '';
            defect.actual_result = row.actual_result || '';

            if (frm.doc.template_type === 'Marketing') {
                defect.notes = row.notes || '';
            } else if (frm.doc.template_type === 'Production') {
                defect.comments = row.comments || '';
                defect.result = row.result || '';
            }

            frappe.set_route('Form', 'Defect', defect.name);
        });

    });
}