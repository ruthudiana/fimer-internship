// Copyright (c) 2025, a and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Marketing Template", {
// 	refresh(frm) {

// 	},
// });
