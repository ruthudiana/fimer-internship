import frappe
from frappe.model.document import Document
from frappe.utils import get_url

class Defect(Document):
    def after_insert(self):
        send_defect_email(self.name)

@frappe.whitelist()
def send_defect_email(defect_name):
    try:
        doc = frappe.get_doc("Defect", defect_name)

        qa_testers = frappe.get_all(
            "Has Role",
            filters={"role": "QA Tester"},
            fields=["parent as user"]
        )
        qa_emails = [
            frappe.db.get_value("User", q.user, "email")
            for q in qa_testers
            if frappe.db.get_value("User", q.user, "email")
        ]

        if not qa_emails:
            frappe.log_error("No QA Tester emails found", "Defect Notification")
            return

        cc_list = []
        for field in ["assigned_to", "assigned_by"]:
            val = doc.get(field)
            if val and "@" in val:
                cc_list.append(val)
            elif val:
                user_email = frappe.db.get_value("User", val, "email")
                if user_email:
                    cc_list.append(user_email)

        attachment_links = "None"
        if doc.get("attachments"):
            attachment_links = "<ul>"
            for file in doc.get("attachments"):
                if file.file_url and file.file_name:
                    attachment_links += f"<li><a href='{get_url()}{file.file_url}' target='_blank'>{file.file_name}</a></li>"
            attachment_links += "</ul>"

        message = f"""
            <h3>New Defect Logged</h3>
            <p>
            <b>Test Case ID:</b> {doc.test_case_id or '-'}<br>
            <b>Title:</b> {doc.test_title or '-'}<br>
            <b>Description:</b> {doc.test_description or '-'}<br>
            <b>Severity:</b> {doc.severity or '-'}<br>
            <b>Priority:</b> {doc.priority or '-'}<br>
            <b>Result:</b> {doc.result or '-'}<br>
            <b>Expected Result:</b> {doc.expected_result or '-'}<br>
            <b>Actual Result:</b> {doc.actual_result or '-'}<br>
            <b>Comments:</b> {doc.comments or '-'}<br>
            <b>Notes:</b> {doc.notes or '-'}<br>
            <b>Attachments:</b><br>{attachment_links}<br>
            </p>
            <hr>
            <p><a href="{get_url()}/app/defect/{doc.name}" target="_blank">Open Defect in ERP</a></p>
        """

        frappe.logger().info(f"Defect Email message content:\n{message}")

        frappe.sendmail(
            recipients=qa_emails,
            cc=cc_list,
            subject=f"[Defect] {doc.test_case_id or doc.name} - {doc.test_title or 'Untitled'}",
            message=message,
            delayed=False
        )

    except Exception:
        frappe.log_error(frappe.get_traceback(), "Defect Email Sending Failed")