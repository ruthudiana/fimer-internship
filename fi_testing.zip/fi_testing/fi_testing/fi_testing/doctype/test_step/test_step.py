# Copyright (c) 2025, a and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class TestStep(Document):
	pass
